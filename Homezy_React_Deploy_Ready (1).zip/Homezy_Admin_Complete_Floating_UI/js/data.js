
const HOMEZY={
services:[
{id:1,name:"Plumbing",icon:"🔧",desc:"Leaks, taps, pipes, bathrooms and water systems.",price:299},
{id:2,name:"Electrical",icon:"⚡",desc:"Switches, wiring, fans, lights and electrical repairs.",price:249},
{id:3,name:"Home Cleaning",icon:"🧹",desc:"Deep cleaning for rooms, kitchens and bathrooms.",price:799},
{id:4,name:"AC Service",icon:"❄️",desc:"AC service, repair, installation and maintenance.",price:499},
{id:5,name:"Appliance Repair",icon:"🛠️",desc:"Washing machine, refrigerator and microwave repair.",price:349},
{id:6,name:"Pest Control",icon:"🐜",desc:"Professional pest treatment for your home.",price:699},
{id:7,name:"Carpentry",icon:"🪚",desc:"Furniture, shelves, doors and custom carpentry.",price:399},
{id:8,name:"Painting",icon:"🎨",desc:"Room painting, touch-ups and complete painting.",price:1499},
{id:9,name:"Water Purifier",icon:"🚰",desc:"RO service, filter replacement and installation.",price:399},
{id:10,name:"Sofa & Carpet",icon:"🛋️",desc:"Professional sofa and carpet cleaning.",price:599},
{id:11,name:"Gardening",icon:"🌱",desc:"Garden maintenance and plant care.",price:449},
{id:12,name:"Moving & Packing",icon:"📦",desc:"Professional packing and local shifting.",price:1299}],
providers:[
{id:101,name:"Raj Kumar",role:"Master Plumber",rating:4.9,jobs:1284,years:7,distance:"2.1 km",initials:"RK"},
{id:102,name:"Arun Prasad",role:"Electrician",rating:4.8,jobs:932,years:6,distance:"1.7 km",initials:"AP"},
{id:103,name:"Sneha Reddy",role:"Cleaning Expert",rating:4.9,jobs:756,years:5,distance:"3.2 km",initials:"SR"},
{id:104,name:"Vikram Singh",role:"AC Technician",rating:4.7,jobs:641,years:8,distance:"4.1 km",initials:"VS"}]
};
