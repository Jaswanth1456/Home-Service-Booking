function showToast(message){const el=document.getElementById('adminToast');if(!el)return;el.textContent=message;el.classList.add('show');clearTimeout(window.__homezyToast);window.__homezyToast=setTimeout(()=>el.classList.remove('show'),2200)}
function filterTable(input){const q=(input.value||'').toLowerCase();const table=document.querySelector('[data-filter-table]');if(!table)return;table.querySelectorAll('tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')}
function setActiveNav(){const file=location.pathname.split('/').pop()||'dashboard.html';document.querySelectorAll('.nav-item').forEach(a=>{a.classList.toggle('active',a.getAttribute('href')===file)})}
document.addEventListener('DOMContentLoaded',setActiveNav);
