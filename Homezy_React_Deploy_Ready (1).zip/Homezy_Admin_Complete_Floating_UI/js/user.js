(function(){
  const u=Store.user()||{name:"Guest User",phone:"+91 9XXXXXXXXX",email:"guest@homezy.app"};
  const bookings=Store.bookings();
  const notifications=Store.notifications();
  const cards=Store.cards();
  const completed=Store.completed();
  const firstName=(u.name||"User").split(" ")[0];
  const initials=(u.name||"U").split(/\s+/).map(x=>x[0]).join("").slice(0,2).toUpperCase();
  const active=bookings.filter(b=>!['Completed','Cancelled'].includes(b.status)).length;
  const spent=bookings.reduce((sum,b)=>sum+Number(b.price||0),0);

  document.body.innerHTML=nav()+`\
  <main class="userDashboard section">
    <div class="container">
      <div class="userHero">
        <div class="userWelcome">
          <div class="userAvatar">${initials}</div>
          <div><span class="badge">✓ Homezy Customer</span><h1>Welcome back, ${firstName}!</h1><p>Manage your bookings, services, payments and account from one place.</p></div>
        </div>
        <a class="btn primary" href="${homezyHref("pages/services.html")}">+ Book a service</a>
      </div>

      <div class="userStats">
        <div class="userStat"><span>📅</span><div><b>${active}</b><small>Active bookings</small></div></div>
        <div class="userStat"><span>✅</span><div><b>${completed.length||bookings.filter(b=>b.status==='Completed').length}</b><small>Completed services</small></div></div>
        <div class="userStat"><span>💰</span><div><b>${money(spent)}</b><small>Total booking value</small></div></div>
        <div class="userStat"><span>💳</span><div><b>${cards.length}</b><small>Saved cards</small></div></div>
      </div>

      <div class="userLayout">
        <section>
          <div class="sectionHead"><div><h2>Quick actions</h2><p class="muted">Everything you need, in one place.</p></div></div>
          <div class="userActionGrid">
            <a class="userAction" href="${homezyHref("pages/bookings.html")}"><span>📦</span><b>My Bookings</b><small>Track and manage services</small></a>
            <a class="userAction" href="${homezyHref("pages/services.html")}"><span>🔧</span><b>Book a Service</b><small>Find trusted professionals</small></a>
            <a class="userAction" href="${homezyHref("pages/favorites.html")}"><span>❤️</span><b>Favorites</b><small>Your saved professionals</small></a>
            <a class="userAction" href="${homezyHref("pages/customer/cards.html")}"><span>💳</span><b>Payments</b><small>Cards and payment methods</small></a>
            <a class="userAction" href="${homezyHref("pages/notifications.html")}"><span>🔔</span><b>Notifications</b><small>${notifications.length} updates available</small></a>
            <a class="userAction" href="${homezyHref("pages/profile.html")}"><span>👤</span><b>My Profile</b><small>Edit personal information</small></a>
            <a class="userAction" href="${homezyHref("pages/customer/rating.html")}"><span>⭐</span><b>My Reviews</b><small>Rate your completed services</small></a>
            <a class="userAction" href="${homezyHref("pages/services.html")}"><span>🛟</span><b>Help & Support</b><small>Get help with your booking</small></a>
          </div>

          <div class="card userRecent">
            <div class="sectionHead"><div><h2>Recent bookings</h2><p class="muted">Your latest Homezy activity.</p></div><a class="btn" href="${homezyHref("pages/bookings.html")}">View all</a></div>
            ${recentBookings()}
          </div>
        </section>

        <aside>
          <div class="card userProfileCard">
            <div class="profileTop"><div class="userAvatar small">${initials}</div><div><h3>${u.name||'Guest User'}</h3><p class="muted">${u.email||'No email added'}</p></div></div>
            <div class="profileInfo"><div><span>📱</span>${u.phone||'No mobile added'}</div><div><span>📍</span>Vijayawada, Andhra Pradesh</div></div>
            <a class="btn primary full" href="${homezyHref("pages/profile.html")}">Edit profile</a>
          </div>

          <div class="card safetyCard"><span class="safetyIcon">🛡️</span><h3>Your safety matters</h3><p class="muted">All listed professionals are verified. Check ratings, experience and service details before booking.</p><button class="btn" onclick="toast('Safety information opened')">Safety information</button></div>

          <div class="card plusCard"><span class="badge">HOMEZY PLUS</span><h3>Get more from Homezy</h3><p class="muted">Priority booking, member discounts and extended support.</p><button class="btn primary" onclick="toast('Homezy Plus enrollment opened')">Explore ₹999/year</button></div>
        </aside>
      </div>
    </div>
  </main>${footer()}<div id="toast" class="toast"></div>`;

  function recentBookings(){
    const list=bookings.slice(0,3);
    if(!list.length) return `<div class="emptyUser"><span>📭</span><h3>No bookings yet</h3><p class="muted">Book your first home service to see it here.</p><a class="btn primary" href="${homezyHref("pages/services.html")}">Browse services</a></div>`;
    return list.map(b=>`<div class="recentRow"><div class="recentIcon">${iconFor(b.service)}</div><div class="recentMain"><b>${b.service||'Home Service'}</b><span>${b.provider||'Assigned professional'} · ${b.date||'Date not set'} · ${b.time||'Time not set'}</span></div><div class="recentRight"><strong>${money(b.price||0)}</strong><span class="badge ${b.status==='Completed'?'success':'warning'}">${b.status||'Booked'}</span></div></div>`).join('');
  }
  function iconFor(s){const x=String(s||'').toLowerCase();if(x.includes('plumb'))return '🔧';if(x.includes('electric'))return '⚡';if(x.includes('clean'))return '🧹';if(x.includes('ac'))return '❄️';if(x.includes('paint'))return '🎨';return '🏠';}
})();
