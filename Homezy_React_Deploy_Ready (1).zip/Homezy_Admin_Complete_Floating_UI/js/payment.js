const id = new URLSearchParams(location.search).get("id");
const booking = Store.bookings().find(x => x.id === id);
if (!booking) {
  document.body.innerHTML = nav()+`<main class="section"><div class="container" style="max-width:700px"><div class="card"><h2>Booking not found</h2><p class="muted">We could not find this booking in this browser. Please return to your bookings and try again.</p><a class="btn primary" href="${homezyHref("pages/bookings.html")}">My Bookings</a></div></div></main>`+footer();
} else {
  document.body.innerHTML = nav()+`<main class="section"><div class="container" style="max-width:700px"><div class="card"><h1>Payment</h1><p class="muted">Booking ${escapeText(booking.id)} · ${escapeText(booking.service)}</p><div class="priceBox"><div class="row"><span>Total payable</span><b class="price">${money(booking.price||0)}</b></div></div><br><div class="form"><div class="field"><label for="paymentMethod">Payment method</label><select id="paymentMethod"><option>UPI (demo)</option><option>Credit / Debit Card (demo)</option><option>Net Banking (demo)</option><option>Cash after service</option></select></div><p class="muted" style="font-size:12px">Demo checkout only. No real money is collected and no card or UPI details are requested.</p><button class="btn primary" onclick="completePayment()">Confirm demo payment</button></div></div></div></main>`+footer()+`<div id="toast" class="toast"></div>`;
}
function escapeText(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function completePayment(){
  const method=document.querySelector("#paymentMethod").value;
  const list=Store.bookings();
  const current=list.find(x=>x.id===id);
  if(!current){toast("Booking not found. Please try again.");return;}
  current.paymentMethod=method;
  current.paymentStatus=method.startsWith("Cash")?"Pay after service":"Demo paid";
  current.status="Confirmed";
  current.processStep=1;
  Store.set("bookings",list.map(x=>x.id===id?current:x));
  toast("Booking confirmed in demo mode");
  setTimeout(()=>location.href=homezyHref("confirmation.html?id="+encodeURIComponent(id)),500);
}
