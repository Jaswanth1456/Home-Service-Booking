
const params=new URLSearchParams(location.search);
const sid=Number(params.get("service")||1);
const pid=Number(params.get("provider")||101);
const pkg=params.get("package")||"";
const packageDiscount=pkg==="starter"?0.05:(pkg==="homecare"||pkg==="annual"?0.10:0);
const s=HOMEZY.services.find(x=>x.id===sid)||HOMEZY.services[0];
const p=HOMEZY.providers.find(x=>x.id===pid)||HOMEZY.providers[0];
const u=Store.user()||{name:"Guest User",phone:"",email:""};

const packageNames={starter:"Starter Package",homecare:"Home Care Package",annual:"Annual Care Package",none:"Single Service"};
const packageLabel=packageNames[pkg]||"Single Service";
const tomorrow=new Date(); tomorrow.setDate(tomorrow.getDate()+1); const defaultDate=[tomorrow.getFullYear(),String(tomorrow.getMonth()+1).padStart(2,"0"),String(tomorrow.getDate()).padStart(2,"0")].join("-");

document.body.innerHTML=nav()+`<main class="section"><div class="container grid g2">
<div class="card"><h2>Book ${s.name}</h2><p class="muted">Enter the customer details and choose a convenient service slot.</p>
<div class="form">
<div class="field"><label>Customer name *</label><input id="customerName" value="${esc(u.name||"")}" placeholder="Enter your full name"></div>
<div class="grid g2">
<div class="field"><label>Phone number *</label><input id="customerPhone" value="${esc(u.phone||"")}" placeholder="+91 XXXXX XXXXX"></div>
<div class="field"><label>Email</label><input id="customerEmail" type="email" value="${esc(u.email||"")}" placeholder="you@example.com"></div>
</div>
<div class="field"><label>Describe the issue / service request *</label><textarea id="issue" placeholder="Describe the work required..."></textarea></div>
<div class="field"><label>Photos / videos (optional)</label><input id="media" type="file" multiple></div>
<div class="grid g2"><div class="field"><label>Date *</label><input id="date" type="date" min="${defaultDate}" value="${defaultDate}"></div>
<div class="field"><label>Preferred time *</label><select id="time"><option>9:00 AM</option><option>10:00 AM</option><option>12:00 PM</option><option>2:00 PM</option><option>4:00 PM</option><option>6:00 PM</option></select></div></div>
<div class="field"><label>Service address *</label><select id="address"><option value="Home — Vijayawada">🏠 Home — Vijayawada</option><option value="College — Vijayawada">🏢 College — Vijayawada</option><option value="custom">+ Add new address</option></select><input id="customAddress" class="hidden" style="margin-top:9px" placeholder="Enter complete service address"></div>
<div class="field"><label>Professional *</label><select id="professional">${HOMEZY.providers.map(x=>`<option value="${x.id}" ${x.id===p.id?"selected":""}>${x.name} — ★${x.rating} · ${x.distance}</option>`).join("")}</select></div>
<div class="grid g2"><div class="field"><label>Service selection</label><select id="package"><option value="none" ${!pkg?"selected":""}>Single Service</option><option value="starter" ${pkg==="starter"?"selected":""}>Starter Package — 5% off</option><option value="homecare" ${pkg==="homecare"?"selected":""}>Home Care Package — 10% off</option><option value="annual" ${pkg==="annual"?"selected":""}>Annual Care Package — 10% off</option></select></div>
<div class="field"><label>Booking type</label><select id="bookingType"><option>One-time</option><option>Weekly recurring</option><option>Monthly recurring</option></select></div></div>
<div class="field"><label>Special instructions / cautions</label><textarea id="cautions" placeholder="Pets, parking instructions, safety concerns, preferred entry instructions, etc."></textarea></div>
</div></div>
<div class="card"><h3>Booking summary</h3><div class="priceBox"><div class="row"><span>${s.name}</span><b>${money(s.price)}</b></div><div class="row"><span id="packageSummary">${packageLabel}</span><b id="discountValue" class="price">${packageDiscount?'-'+money(Math.round(s.price*packageDiscount)):'₹0'}</b></div><div class="row"><span>Platform & safety fee</span><span>₹49</span></div><div class="row"><span>Tax estimate</span><span>₹45</span></div><div class="row" style="border-top:1px solid var(--line);padding-top:13px"><b>Total</b><b id="totalPrice" class="price">${money(Math.max(0,Math.round(s.price*(1-packageDiscount)+94)))}</b></div></div><br>
<div class="provider"><div class="avatar">${p.initials}</div><div><b id="providerName">${p.name} ✓</b><div class="muted">${p.role}</div><div class="rating">★ ${p.rating} · ${p.jobs} jobs · ${p.distance}</div></div></div><br>
<div class="card" style="background:var(--soft);border:1px solid var(--line)"><b>Customer details</b><p id="customerPreview" class="muted" style="margin:7px 0">${esc(u.name||"Guest User")} · ${esc(u.phone||"Phone not added")}<br>${esc(u.email||"Email not added")}</p></div><br>
<button class="btn primary" style="width:100%" onclick="pay()">Continue to secure payment →</button><p class="muted" style="font-size:12px;margin-top:12px">Payments shown here are demo-only for this HTML/CSS/JS project.</p>
</div></div></main>${footer()}<div id="toast" class="toast"></div>`;

document.querySelector("#address").addEventListener("change",e=>{const field=document.querySelector("#customAddress");field.classList.toggle("hidden",e.target.value!=="custom");if(e.target.value==="custom")field.focus();});
document.querySelector("#professional").addEventListener("change",e=>{
 const np=HOMEZY.providers.find(x=>x.id===Number(e.target.value))||p;
 document.querySelector("#providerName").textContent=np.name+" ✓";
});
["customerName","customerPhone","customerEmail"].forEach(id=>document.querySelector("#"+id).addEventListener("input",()=>{
 const n=document.querySelector("#customerName").value||"Guest User",ph=document.querySelector("#customerPhone").value||"Phone not added",em=document.querySelector("#customerEmail").value||"Email not added";
 document.querySelector("#customerPreview").innerHTML=`${esc(n)} · ${esc(ph)}<br>${esc(em)}`;
}));
document.querySelector("#package").addEventListener("change",e=>{
 const d={none:0,starter:.05,homecare:.10,annual:.10}[e.target.value]||0;
 document.querySelector("#totalPrice").textContent=money(Math.max(0,Math.round(s.price*(1-d)+94)));
 document.querySelector("#discountValue").textContent=d?"-"+money(Math.round(s.price*d)):"₹0";
 document.querySelector("#packageSummary")?.replaceChildren(document.createTextNode(packageNames[e.target.value]||"Single Service"));
});

function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));}
function pay(){
 const name=document.querySelector("#customerName").value.trim();
 const phone=document.querySelector("#customerPhone").value.trim();
 const issue=document.querySelector("#issue").value.trim();
 const date=document.querySelector("#date").value;
 const addressSelect=document.querySelector("#address").value;
 const address=addressSelect==="custom"?document.querySelector("#customAddress").value.trim():addressSelect;
 const email=document.querySelector("#customerEmail").value.trim();
 if(!name||!phone){toast("Please enter customer name and phone number");return;}
 if(!/^[+\d][\d\s-]{8,15}$/.test(phone)){toast("Please enter a valid phone number");return;}
 if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){toast("Please enter a valid email address");return;}
 if(!issue){toast("Please describe the service request");document.querySelector("#issue").focus();return;}
 if(!date||date<defaultDate){toast("Please choose a valid future date");return;}
 if(!address){toast("Please enter the complete service address");document.querySelector("#customAddress").focus();return;}
 const selectedProvider=HOMEZY.providers.find(x=>x.id===Number(document.querySelector("#professional").value))||p;
 const selectedPackage=document.querySelector("#package").value;
 const discount={none:0,starter:.05,homecare:.10,annual:.10}[selectedPackage]||0;
 const b={
   id:"HZ"+Math.floor(10000+Math.random()*89999),
   service:s.name,serviceId:s.id,
   provider:selectedProvider.name,providerId:selectedProvider.id,
   providerRating:selectedProvider.rating,providerDistance:selectedProvider.distance,
   customer:{name,phone,email:document.querySelector("#customerEmail").value.trim()},
   customerName:name,customerPhone:phone,customerEmail:document.querySelector("#customerEmail").value.trim(),
   date:document.querySelector("#date").value,time:document.querySelector("#time").value,
   price:Math.max(0,Math.round(s.price*(1-discount)+94)),
   basePrice:s.price,package:selectedPackage,packageName:packageNames[selectedPackage]||"Single Service",
   packageDiscount:Math.round(s.price*discount),
   bookingType:document.querySelector("#bookingType").value,
   status:"Pending Payment",paymentStatus:"Pending",
   address,issue,mediaFiles:[...document.querySelector("#media").files].map(f=>({name:f.name,type:f.type,size:f.size})),
   cautions:document.querySelector("#cautions").value.trim(),
   createdAt:new Date().toISOString(),processStep:0
 };
 Store.addBooking(b);
 location.href=homezyHref("pages/payment.html?id="+encodeURIComponent(b.id));
}
