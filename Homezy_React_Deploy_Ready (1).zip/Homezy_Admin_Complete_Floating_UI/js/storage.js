
const Store={
get:(k,d=[])=>{try{return JSON.parse(localStorage.getItem("homezy_"+k))??d}catch{return d}},
set:(k,v)=>localStorage.setItem("homezy_"+k,JSON.stringify(v)),
user:()=>Store.get("user",null),
bookings:()=>Store.get("bookings",[]),
addBooking:b=>{let x=Store.bookings();x.unshift(b);Store.set("bookings",x)},
workers:()=>Store.get("workers",[]),
addWorker:w=>{let x=Store.workers();x.unshift(w);Store.set("workers",x)},
reviews:()=>Store.get("reviews",[]),
addReview:r=>{let x=Store.reviews();x.unshift(r);Store.set("reviews",x)},
cards:()=>Store.get("cards",[]),
addCard:c=>{let x=Store.cards();x.push(c);Store.set("cards",x)},
payments:()=>Store.get("payments",[]),
addPayment:p=>{let x=Store.payments();x.unshift(p);Store.set("payments",x)},
completed:()=>Store.get("completed",[]),
addCompleted:c=>{let x=Store.completed();x.unshift(c);Store.set("completed",x)},
notifications:()=>Store.get("notifications",[]),
addNotification:n=>{let x=Store.notifications();x.unshift(n);Store.set("notifications",x)},
init:()=>{
 if(!localStorage.getItem("homezy_user"))Store.set("user",{name:"Guest User",phone:"+91 9XXXXXXXXX",email:"guest@homezy.app",role:"customer"});
 if(!localStorage.getItem("homezy_workers"))Store.set("workers",[
  {id:"W1001",name:"Raj Kumar",work:"Plumbing",experience:7,status:"Active",rating:4.9,revenue:68450,customers:1284},
  {id:"W1002",name:"Vikram Singh",work:"AC Technician",experience:8,status:"Active",rating:4.7,revenue:52100,customers:641}
 ]);
 if(!localStorage.getItem("homezy_admin"))Store.set("admin",{username:"admin",keyword:"admin"});
}};
Store.init();
