# HOMEZY — Pure HTML + CSS + JavaScript

A realistic frontend-only home-services booking platform.

## Run
No installation is required.

Open `index.html` in a browser.

For best results with browser security restrictions, run a local static server:
- VS Code Live Server, or
- Python: `python -m http.server 5500`

Then open `http://localhost:5500/`

## Main modules
Customer:
- Service marketplace
- Search
- Provider profiles
- Booking
- Date/time slots
- Address selection
- Recurring booking UI
- Price calculation
- Payment demo
- Booking history
- Live tracking simulation
- Notifications
- Favorites
- Profile
- Emergency service

Provider:
- Dashboard
- Today's jobs
- Availability
- Earnings
- Services
- Messaging controls

Admin:
- Dashboard
- Users
- Providers/KYC
- Bookings
- Services
- Payments
- Disputes
- Analytics

## Storage
Bookings and profile data use browser `localStorage`, so this remains a frontend-only project.

## Important
Real card/UPI payment processing, OTP SMS, GPS location, cloud database,
multi-device accounts, push notifications, and real-time chat require external
services/backend infrastructure. This project intentionally keeps those parts
as realistic demo interfaces because the requirement is only HTML/CSS/JavaScript.


## V2 additions
- Single customer login/register page.
- Passwords containing the keyword `admin` trigger hidden admin verification.
- Customer booking history, ratings and optional comments.
- Saved payment cards.
- Service packages with 5% / 10% discounts.
- Worker registration and resume submission to Admin.
- Worker dashboard with customers, revenue, ratings and performance.
- Workers do not see individual customer comments.
- Workers must submit completion photos after jobs.
- Admin can review worker applications/resume metadata.
- Admin payroll/payment controls.
- Admin customer-performance analytics and review moderation.
- Admin completion-photo verification.
- Admin can approve/reject workers and manage their Homezy status.

## Booking flow improvements in this build
- Booking form validates name, phone, optional email, service request, future date and service address.
- Custom service addresses can be entered instead of selecting only the sample addresses.
- Package selection updates the booking summary and total.
- Selected attachment names and metadata are saved with the booking (the actual files are not uploaded or persisted).
- Payment page verifies that the booking exists before showing checkout.
- Payment is explicitly a demo flow; it does not charge a card, UPI account or bank account.
- My Bookings lists customer and service details, supports tracking and lets users cancel eligible bookings.

## Test the booking flow
1. Run the project with VS Code Live Server from this folder's `index.html`.
2. Choose a service and press **Book**.
3. Complete the required fields and press **Continue to secure payment**.
4. Choose a demo payment method and confirm.
5. Open **Bookings** to see the saved booking; use **Track** or **Cancel** as needed.

## Prototype limitations
This is a client-side academic/demo project, not a production-ready marketplace. Browser Local Storage is not a secure database and is limited to the current browser profile/device. Login is a demonstration only; passwords are not securely authenticated. Admin pages include sample/demo operational data. Real payments, OTP verification, file uploads, worker/customer messaging, maps/GPS, notifications and multi-device synchronization need a secure backend and third-party integrations before real users or payments are involved.


## React version
A React + Vite implementation of the customer-facing Homezy flow is included in `react-app/`. See `react-app/README.md` for setup. The original HTML/CSS/JavaScript pages are preserved in this project.
