# Homezy React Edition

This folder contains a React + Vite single-page application for the Homezy customer flow. The original HTML/CSS/JS project is preserved in the parent folder, including its worker and admin pages.

## Requirements
- Node.js 18.0 or newer
- npm

## Run locally
1. Open this `react-app` folder in VS Code.
2. Open Terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite (usually http://localhost:5173).

## Production build
Run `npm run build`. The production files are generated in `dist/`. Run `npm run preview` to preview the build.

## React routes
- `/` Home
- `/services` Service catalogue and search
- `/book/:id` Booking form
- `/bookings` Booking history and cancellation
- `/login` Demo profile setup
- `/worker` Worker dashboard and job management
- `/worker/login` Worker registration

## Storage and integration notes
The React demo stores its customer profile and bookings in browser Local Storage using the `homezy_` prefix. This makes it a frontend prototype, not a production booking platform. Real authentication, payments, worker assignment, admin APIs, notifications and GPS tracking require a secure backend. The existing static worker/admin pages remain available in the parent project under `pages/`.

## Deploy
### Netlify
1. Push the project to GitHub.
2. In Netlify, choose **Add new site → Import an existing project**.
3. Select the GitHub repository.
4. Set **Base directory** to `Homezy_Admin_Complete_Floating_UI/react-app`.
5. Build command: `npm run build`
6. Publish directory: `dist`
7. Deploy. The included `netlify.toml` handles React route refreshes.

### Vercel
1. Import the GitHub repository in Vercel.
2. Set the project Root Directory to `Homezy_Admin_Complete_Floating_UI/react-app`.
3. Framework preset: Vite; Build command: `npm run build`; Output directory: `dist`.
4. Deploy. The included `vercel.json` supports React Router routes.

Note: this is a frontend demonstration. Local Storage data stays in each browser and is not shared between customers, workers, and admins on different devices. Real authentication, shared job assignment, verification, GPS, chat, payments and notifications require a backend.
